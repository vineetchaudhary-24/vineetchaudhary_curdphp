<?php
header("Location: /vineet-crud-php/frontend/");
exit;
?>