
        

        const form = document.getElementById('taskForm');
        const taskList = document.getElementById('taskList');
        const taskIdField = document.getElementById('taskId');
        const cancelEditBtn = document.getElementById('cancelEdit');
        const baseFolder = window.location.pathname.split('/')[1];
        

        function showMessage(message, type = 'success') {
            const box = document.getElementById('messageBox');
            box.className = `alert alert-${type} mt-3`; 
            box.innerText = message;
            box.classList.remove('d-none');
        
          
            setTimeout(() => {
                box.classList.add('d-none');
            }, 3000);
        }
        // Load tasks initially
        loadTasks();

        // Save or update task
        form.onsubmit = async function(e) {
            e.preventDefault();
            const title = document.getElementById('title').value;
            const description = document.getElementById('description').value;
            const id = taskIdField.value;
        
            const method = id ? 'PUT' : 'POST';
            
            const url = id 
                ? `/${baseFolder}/api/controllers/TaskController.php/${id}` 
                : `/${baseFolder}/api/controllers/TaskController.php`;

            await fetch(url, {
                method,
                body: JSON.stringify({ title, description }),
                headers: { 'Content-Type': 'application/json' }
            });

            form.reset();
            taskIdField.value = '';
            cancelEditBtn.classList.add('d-none');
            showMessage(id ? 'Task updated successfully!' : 'Task added successfully!', 'success');
            loadTasks();
        };

        // Load tasks
        async function loadTasks() {
            taskList.innerHTML = '';
            const res = await fetch(`/${baseFolder}/api/controllers/TaskController.php`);
            const tasks = await res.json();

            tasks.forEach(t => {
                const li = document.createElement('li');
                li.className = 'list-group-item d-flex justify-content-between align-items-center';

                li.innerHTML = `
                    <div>
                        <strong>${t.title}</strong><br>
                        <small>${t.description}</small>
                    </div>
                    <div>
                        <button onclick="editTask(${t.id})" class="btn btn-sm btn-warning me-2">Edit</button>
                        <button onclick="deleteTask(${t.id})" class="btn btn-sm btn-danger">Delete</button>
                    </div>
                `;
                taskList.appendChild(li);
            });
        }

        // Delete task
        async function deleteTask(id) {
            await fetch(`/${baseFolder}/api/controllers/TaskController.php/${id}`, { method: 'DELETE' });
            showMessage(id ? 'Task deleted successfully!' : 'Task deleted successfully!', 'success');
            loadTasks();
        }

        // Edit task 
        async function editTask(id) {
            const res = await fetch(`/${baseFolder}/api/controllers/TaskController.php/${id}`);
            const task = await res.json();

            document.getElementById('title').value = task.title;
            document.getElementById('description').value = task.description;
            taskIdField.value = task.id;
            cancelEditBtn.classList.remove('d-none');
        }

        // Cancel Edit
        cancelEditBtn.onclick = function () {
            form.reset();
            taskIdField.value = '';
            cancelEditBtn.classList.add('d-none');
        };
