<?php
require_once '../config/Database.php';
require_once '../models/Task.php';

$db = (new Database())->connect();
$task = new Task($db);

$method = $_SERVER['REQUEST_METHOD'];
$request = explode("/", trim($_SERVER['REQUEST_URI'], "/"));
$id = $request[count($request) - 1] ?? null;

header("Content-Type: application/json");

switch ($method) {
    case 'GET':
        if (is_numeric($id)) echo json_encode($task->readOne($id));
        else echo json_encode($task->readAll()->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        $task->title = htmlspecialchars(strip_tags($data->title));
        $task->description = htmlspecialchars(strip_tags($data->description));
        echo json_encode(["success" => $task->create()]);
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        $task->title = htmlspecialchars(strip_tags($data->title));
        $task->description = htmlspecialchars(strip_tags($data->description));
        echo json_encode(["success" => $task->update($id)]);
        break;

    case 'DELETE':
        echo json_encode(["success" => $task->delete($id)]);
        break;
}
?>
